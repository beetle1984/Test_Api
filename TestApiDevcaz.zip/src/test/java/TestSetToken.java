
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.junit.Test;

public class TestSetToken {

    @Test
    public void postRequestExampleTest() {
        
        RequestSpecification request = RestAssured.given();

        request.contentType(ContentType.JSON).body("{"
                + "\"grant_type\": \"client_credentials\"}");
        request.auth().preemptive().basic("front_2d6b0a8391742f5d789d7d915755e09e", "");
        request.header("Content-Type", "application/json");
        
        Response response = request.post("http://test-api.d6.dev.devcaz.com/v2/oauth2/token");

        int statusCode = response.getStatusCode();
        String token = response.path("access_token").toString();
        String successCode = response.jsonPath().get("statusCode");
        Assert.assertEquals(200, statusCode);
        System.out.println("token = " + token);
        System.out.println("response code = " + statusCode);
       
    }

}
