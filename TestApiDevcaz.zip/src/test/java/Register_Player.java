
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.util.Base64;
import org.junit.Assert;
import org.junit.Test;

public class Register_Player {

    @Test
    public void postRequestExampleTest() {
        String password_change = "LexaKlec1";
        String password_repeat = "LexaKlec1";
        String encoded_password_change = Base64.getEncoder().encodeToString(password_change.getBytes());
        String encoded_password_repeat = Base64.getEncoder().encodeToString(password_repeat.getBytes());

        RequestSpecification request = RestAssured.given();

        request.contentType(ContentType.JSON).body("{\n"
                + "\"username\":\"KlecLexa\", \n"
                + "\"password_change\":\"TGV4YUtsZWMx\",\n"
                + "\"password_repeat\":\" TGV4YUtsZWMx\", \n"
                + "\"email\":\"alekseyklec@gmail.com\"\n"
                + "\n"
                + "}");

        request.auth().preemptive().oauth2("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjkzODZiNzQ2ZmMxMTkwZDE4YTU5ZTNjNWE0Nzc5MDUyNjg1MTU0OGFjNWZlOTBmYjYwNWVmYTAxYmJlZTZlMDk5NzAyMTE4MDc4YWQzYmIyIn0.eyJhdWQiOiJmcm9udF8yZDZiMGE4MzkxNzQyZjVkNzg5ZDdkOTE1NzU1ZTA5ZSIsImp0aSI6IjkzODZiNzQ2ZmMxMTkwZDE4YTU5ZTNjNWE0Nzc5MDUyNjg1MTU0OGFjNWZlOTBmYjYwNWVmYTAxYmJlZTZlMDk5NzAyMTE4MDc4YWQzYmIyIiwiaWF0IjoxNTU4MTY4NzU5LCJuYmYiOjE1NTgxNjg3NTksImV4cCI6MTU1ODI1NTE1OSwic3ViIjoiIiwic2NvcGVzIjpbImd1ZXN0OmRlZmF1bHQiXX0.uOpkPTP_MtzGR9pnwOtQ9YzN3qb8w6cDXzMxwELW5KjlibIVMShEBVRpeyc0V5Jhoeow4ruSQh6dFC_aSDIDYSg6MqWJ1gEEnmFx3hSwyExTh96XcOYFBWDeNjZ1cFTNkj22UxqnNdZlRcpRnoa5Rnzu9BGAnMlkPHDpubrJryY");
        request.header("Content-Type", "application/json");
        Response response = request.post("http://test-api.d6.dev.devcaz.com/v2/players");

        int statusCode = response.getStatusCode();
        String successCode = response.jsonPath().get("statusCode");
        Assert.assertEquals(201, statusCode);
        System.out.println("response code = " + statusCode);

    }

}
