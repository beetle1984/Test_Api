
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.junit.Test;

public class Player_profile {

    @Test
    public void postRequestExampleTest() {
       
        RequestSpecification request = RestAssured.given();
        String id="215";
        request.auth().preemptive().oauth2("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImVjNjRhNGQyNmU5MDM2OTI1MjlhOTcyMDRmYWY3MTlmMmZmMDJmZTMzYmFmMzMwYTNlYjg0YjIxNTNiZjA3NDFlZDYzNzYyMzA1MTIyY2U3In0.eyJhdWQiOiJmcm9udF8yZDZiMGE4MzkxNzQyZjVkNzg5ZDdkOTE1NzU1ZTA5ZSIsImp0aSI6ImVjNjRhNGQyNmU5MDM2OTI1MjlhOTcyMDRmYWY3MTlmMmZmMDJmZTMzYmFmMzMwYTNlYjg0YjIxNTNiZjA3NDFlZDYzNzYyMzA1MTIyY2U3IiwiaWF0IjoxNTU4MjUzODk3LCJuYmYiOjE1NTgyNTM4OTcsImV4cCI6MTU1ODM0MDI5Niwic3ViIjoiMjcyIiwic2NvcGVzIjpbImJvbnVzOnJlYWQiLCJnYW1lOnJlYWQiLCJnYW1lX2hpc3Rvcnk6cmVhZCIsImphY2twb3Q6cmVhZCIsInBheW1lbnQ6cmVhZCIsInBsYXllcjpyZWFkIiwid2lubmVyOnJlYWQiLCJjYXNpbm86cmVhZCIsIm1lc3NhZ2U6cmVhZCIsImZhcTpyZWFkIiwibG95YWx0eTpyZWFkIiwiZ2FtZTp3cml0ZSIsInBheW1lbnQ6d3JpdGUiLCJwbGF5ZXI6d3JpdGUiLCJtZXNzYWdlOndyaXRlIl19.qUTcC4sQwuvAc3IcRDtA2a88mGEst3YKkYZkfsmBCW4pkz0DQg3lSGvN1rgfaNYqxMIFO_74R3ExNPLSMufHxoIce0l5jgyhKG3syMlHJR7E8vYY79MRpDNuoXsk9XUMGhDsr-AQXcjMXoPTLLtrHfBVw-DX1_yG1dxYw7R0YTk");
        request.header("Content-Type", "application/json");
        Response response = request.get("http://test-api.d6.dev.devcaz.com/v2/players/" + id);

        int statusCode = response.getStatusCode();
        String successCode = response.jsonPath().get("statusCode");   
        String email = response.jsonPath().get("email");
        Assert.assertEquals(200, statusCode);
        System.out.println("response code = " + statusCode);
        System.out.println("email = " + email);
    }

}
